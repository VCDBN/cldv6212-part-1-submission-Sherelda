﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace cldvbst10083869
{
    public static class vaccinationstatus
    {
        [FunctionName("st10083869")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string id = req.Query["id"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            id = id ?? data?.id;
           //if statement is used 
           //code attribution:
          // w3school 'C# If ... Else (no date)
         //Available at: https://www.w3schools.com/cs/cs_conditions.php.
                 
         //if is used to block of code to be executed if the condition is true 
            if (string.IsNullOrEmpty(id))
            {
                string responseMessage = " Welcome!!! " +
                 "\n Please enter your indentification /passport number at the end of the url followed by a question mark and id eg '?id=1234567878 '";
                return new BadRequestObjectResult(responseMessage);
            }

            if (int.TryParse(id, out int idInt))
            {
                string vaccinationstatus = Genratevaccinationstatus(idInt);
                string responseMessage = $" This is the status of : " + vaccinationstatus;
                return new OkObjectResult(responseMessage);
            }
            //else is used to block the code to be executed if the condition is false 
            else
            {
                string responseMessage = "Invalid Identification number . Please enter an ID number that has been stored in the system.";
                return new BadRequestObjectResult(responseMessage);
            }
        }

        //code attribution:
       //Strube, K. (2022) “Easy generation of fake/dummy data in C# with Faker.Net 🕵️,” elmah.io Blog - .NET Technical Tutorials/Guides and New Features [Preprint]. 
      //Available at: https://blog.elmah.io/easy-generation-of-fake-dummy-data-in-c-with-faker-net/.

     //Data populated with id number ,vaccinationstatus and the dates
    //Generate is used 8in this codde to collect and display the details of the id numbers 
        public static string Genratevaccinationstatus(int id)
        {
            if (id <= 0305167890) return "0305167890 : is partially vaccinated" +
                                         "\n has taken the Pfizer vaccine" +
                                         "\n Taken on : 10-06-2021." +
                                         "\n Please note you will be due in the next 30 days for your next dose";
            if (id <= 1234567811) return "1234567811 : is Fully vaccinated " +
                                         "\n has taken the Johnson & johnson vaccince" +
                                         "\n Taken on : 30-05-2021.";
            if (id <= 1334567822) return "1334567822 : is Fully vaccinated " +
                                         "\n has taken 2 doses of the  Pfizer vaccine the " +
                                         "\n 1st dose taken on : 13-05-2021 " +
                                         "\n 2nd dose taken on : 10-06-2021.";
            if (id <= 1434567833) return "1434567833 : is Fully vaccinated" +
                                         "\n has taken the Johnson & johnson vaccincen " +
                                         "\n Taken on: 30-05-2021.";

            return " ID number not found ,Please insert a vaild identification number";


        }

    }
}

